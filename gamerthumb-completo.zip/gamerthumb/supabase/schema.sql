-- ═══════════════════════════════════════════════════
--  GamerThumb — Schema Supabase
--  Cole isso no SQL Editor do seu projeto Supabase
--  (https://supabase.com → SQL Editor → New Query)
-- ═══════════════════════════════════════════════════

-- ── 1. EXTENSÕES ────────────────────────────────────
create extension if not exists "uuid-ossp";

-- ── 2. TABELA: profiles ─────────────────────────────
-- Criada automaticamente após auth.users
create table if not exists public.profiles (
  id            uuid references auth.users(id) on delete cascade primary key,
  email         text,
  name          text,
  username      text unique,
  avatar_url    text,
  channel_color text default '#e8362a',
  channel_font  text default 'Bebas Neue',
  plan          text default 'free' check (plan in ('free','criador','pro')),
  thumbs_used   int  default 0,
  thumbs_limit  int  default 5,
  stripe_id     text,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

-- ── 3. TABELA: thumbnails ───────────────────────────
create table if not exists public.thumbnails (
  id          uuid default uuid_generate_v4() primary key,
  user_id     uuid references public.profiles(id) on delete cascade,
  title       text not null,
  game        text,
  template    text,
  canvas_data jsonb,          -- estado completo do editor em JSON
  image_url   text,           -- URL da imagem exportada no Storage
  views       int  default 0,
  ctr         numeric(5,2) default 0,
  clicks      int  default 0,
  created_at  timestamptz default now(),
  updated_at  timestamptz default now()
);

-- ── 4. TABELA: ab_tests ─────────────────────────────
create table if not exists public.ab_tests (
  id           uuid default uuid_generate_v4() primary key,
  user_id      uuid references public.profiles(id) on delete cascade,
  thumb_a_id   uuid references public.thumbnails(id),
  thumb_b_id   uuid references public.thumbnails(id),
  winner_id    uuid references public.thumbnails(id),
  status       text default 'running' check (status in ('running','finished')),
  created_at   timestamptz default now()
);

-- ── 5. TABELA: subscriptions ────────────────────────
create table if not exists public.subscriptions (
  id                  uuid default uuid_generate_v4() primary key,
  user_id             uuid references public.profiles(id) on delete cascade,
  stripe_sub_id       text unique,
  stripe_price_id     text,
  plan                text,
  status              text,
  current_period_end  timestamptz,
  created_at          timestamptz default now()
);

-- ── 6. TRIGGER: cria profile ao registrar ───────────
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, email, name)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'name', split_part(new.email,'@',1))
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ── 7. TRIGGER: atualiza updated_at ─────────────────
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;

create trigger set_profiles_updated_at    before update on public.profiles    for each row execute procedure public.set_updated_at();
create trigger set_thumbnails_updated_at  before update on public.thumbnails  for each row execute procedure public.set_updated_at();

-- ── 8. RLS (Row Level Security) ─────────────────────
alter table public.profiles    enable row level security;
alter table public.thumbnails  enable row level security;
alter table public.ab_tests    enable row level security;
alter table public.subscriptions enable row level security;

-- profiles: usuário lê/edita apenas o próprio
create policy "profiles_select" on public.profiles for select using (auth.uid() = id);
create policy "profiles_update" on public.profiles for update using (auth.uid() = id);

-- thumbnails: usuário acessa apenas as suas
create policy "thumbnails_select" on public.thumbnails for select using (auth.uid() = user_id);
create policy "thumbnails_insert" on public.thumbnails for insert with check (auth.uid() = user_id);
create policy "thumbnails_update" on public.thumbnails for update using (auth.uid() = user_id);
create policy "thumbnails_delete" on public.thumbnails for delete using (auth.uid() = user_id);

-- ab_tests
create policy "abtests_select" on public.ab_tests for select using (auth.uid() = user_id);
create policy "abtests_insert" on public.ab_tests for insert with check (auth.uid() = user_id);

-- subscriptions
create policy "subs_select" on public.subscriptions for select using (auth.uid() = user_id);

-- ── 9. STORAGE BUCKET ───────────────────────────────
-- Cria bucket para imagens das thumbnails
insert into storage.buckets (id, name, public)
values ('thumbnails', 'thumbnails', true)
on conflict do nothing;

create policy "thumb_images_select" on storage.objects
  for select using (bucket_id = 'thumbnails');

create policy "thumb_images_insert" on storage.objects
  for insert with check (bucket_id = 'thumbnails' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "thumb_images_delete" on storage.objects
  for delete using (bucket_id = 'thumbnails' and auth.uid()::text = (storage.foldername(name))[1]);

-- ── 10. FUNÇÃO: resetar uso mensal ──────────────────
-- Chame via Supabase Cron ou Edge Function no dia 1 de cada mês
create or replace function public.reset_monthly_usage()
returns void language plpgsql security definer as $$
begin
  update public.profiles set thumbs_used = 0;
end;
$$;

-- ─────────────────────────────────────────────────────
--  ✅ Schema pronto! Próximos passos:
--  1. Ative Auth > Email no painel do Supabase
--  2. Configure Storage (já criado acima)
--  3. Rode o servidor: npm run dev
-- ─────────────────────────────────────────────────────
